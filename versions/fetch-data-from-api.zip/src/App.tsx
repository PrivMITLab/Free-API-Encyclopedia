import { useState, useEffect, useRef } from "react";

interface APIData {
  id: number;
  name: string;
  category: string;
  categoryIcon: string;
  provider: string;
  auth: "Key" | "NONE";
  authDetails: string;
  limits: string;
  dailyLimit: string;
  monthlyLimit: string;
  description: string;
  link: string;
  endpoint?: string;
  method?: string;
  curl?: string;
  tags: string[];
  howToUse: string;
  tips: string;
  hasLiveDemo: boolean;
  liveDemoUrl?: string;
}

export default function App() {
  const [allApis, setAllApis] = useState<APIData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedAuth, setSelectedAuth] = useState("All");
  const [selectedApi, setSelectedApi] = useState<APIData | null>(null);
  const [showSearchSuggestions, setShowSearchSuggestions] = useState(false);
  const [liveDemoResponse, setLiveDemoResponse] = useState<any>(null);
  const [liveDemoLoading, setLiveDemoLoading] = useState(false);
  const [liveDemoError, setLiveDemoError] = useState<string | null>(null);

  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchData();

    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSearchSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await fetch("/data/api.json");
      if (!response.ok) {
        throw new Error("Failed to fetch API data");
      }
      const data = await response.json();
      setAllApis(data);
    } catch (error) {
      console.error("Error loading JSON:", error);
    } finally {
      setLoading(false);
    }
  };

  const categories = ["All", ...Array.from(new Set(allApis.map((api) => api.category)))];

  const filteredApis = allApis.filter((api) => {
    const matchesSearch =
      api.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      api.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      api.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
      api.provider.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || api.category === selectedCategory;
    const matchesAuth = selectedAuth === "All" || api.auth === selectedAuth;
    return matchesSearch && matchesCategory && matchesAuth;
  });

  const suggestions = searchQuery.trim()
    ? allApis
        .filter((api) => api.name.toLowerCase().includes(searchQuery.toLowerCase()))
        .slice(0, 5)
    : [];

  const handleTryLive = async (api: APIData) => {
    if (!api.liveDemoUrl) return;
    setLiveDemoLoading(true);
    setLiveDemoError(null);
    setLiveDemoResponse(null);

    // Using AllOrigins CORS proxy for web safety and avoiding CORS issues
    const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(api.liveDemoUrl)}`;

    try {
      const response = await fetch(proxyUrl);
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const text = await response.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        data = { responseText: text }; // Fallback for non-JSON content
      }
      setLiveDemoResponse(data);
    } catch (err: any) {
      setLiveDemoError(err.message || "Failed to fetch. CORS or network issue.");
    } finally {
      setLiveDemoLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Copied to clipboard!");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-purple-500 selection:text-white">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 p-4 md:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🚀</span>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                API Encyclopedia
              </h1>
              <p className="text-xs text-slate-400">The Ultimate Free APIs Hub (2026)</p>
            </div>
          </div>

          <div ref={searchRef} className="relative flex-1 max-w-md">
            <div className="relative">
              <input
                type="text"
                placeholder="Search APIs, tags, or features..."
                className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all text-slate-100 placeholder-slate-400"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowSearchSuggestions(true);
                }}
                onFocus={() => setShowSearchSuggestions(true)}
              />
              <span className="absolute left-3 top-2.5 text-slate-400">🔍</span>
            </div>

            {showSearchSuggestions && suggestions.length > 0 && (
              <div className="absolute top-full mt-1 w-full bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 overflow-hidden divide-y divide-slate-700">
                {suggestions.map((api) => (
                  <button
                    key={api.id}
                    onClick={() => {
                      setSelectedApi(api);
                      setSearchQuery("");
                      setShowSearchSuggestions(false);
                    }}
                    className="w-full px-4 py-3 flex items-center justify-between hover:bg-slate-700/50 transition-colors text-left"
                  >
                    <div>
                      <div className="font-semibold text-slate-100 text-sm">{api.name}</div>
                      <div className="text-xs text-slate-400">{api.provider}</div>
                    </div>
                    <span className="text-xs text-slate-400">{api.categoryIcon} {api.category}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto p-4 md:p-8">
        {/* Category & Filters Section */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 mr-1">Categories:</span>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  selectedCategory === cat
                    ? "bg-purple-600 text-white shadow-lg shadow-purple-500/30"
                    : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 mr-1">Auth Type:</span>
            {["All", "NONE", "Key"].map((auth) => (
              <button
                key={auth}
                onClick={() => setSelectedAuth(auth)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  selectedAuth === auth
                    ? "bg-pink-600 text-white shadow-lg shadow-pink-500/30"
                    : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}
              >
                {auth === "All" ? "Any Auth" : auth === "Key" ? "🔒 Key Required" : "🔓 No Key Required"}
              </button>
            ))}
          </div>
        </div>

        {/* Loading / Cards Grid */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400 space-y-3">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-t-purple-500 border-slate-800"></div>
            <span className="text-sm font-medium">Real-time JSON syncing...</span>
          </div>
        ) : filteredApis.length === 0 ? (
          <div className="text-center py-20">
            <span className="text-4xl">🤷‍♂️</span>
            <h3 className="mt-4 text-lg font-semibold text-slate-200">No APIs found for your filters.</h3>
            <p className="text-sm text-slate-400 mt-1">Try tweaking your search or filtering options.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredApis.map((api) => (
              <div
                key={api.id}
                onClick={() => setSelectedApi(api)}
                className="group relative bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-xl p-6 hover:border-purple-500/50 transition-all cursor-pointer flex flex-col justify-between h-full hover:shadow-xl hover:shadow-purple-500/5"
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl bg-slate-800 p-2 rounded-lg group-hover:bg-purple-500/10 transition-colors">
                        {api.categoryIcon}
                      </span>
                      <div>
                        <h3 className="font-bold text-slate-100 text-md group-hover:text-purple-400 transition-colors">
                          {api.name}
                        </h3>
                        <p className="text-xs text-slate-400 font-medium">{api.provider}</p>
                      </div>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-1 rounded tracking-wide ${
                        api.auth === "NONE"
                          ? "bg-green-500/20 text-green-400"
                          : "bg-amber-500/20 text-amber-400"
                      }`}
                    >
                      {api.auth}
                    </span>
                  </div>

                  <p className="text-sm text-slate-400 line-clamp-2">{api.description}</p>

                  <div className="flex flex-wrap gap-1.5">
                    {api.tags.slice(0, 3).map((tag) => (
                      <span key={tag} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <span>Limits: {api.limits}</span>
                  <span className="text-purple-400 group-hover:translate-x-1 transition-transform">Details &rarr;</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* API Details Sidebar / Modal (Ultra Sleek) */}
      {selectedApi && (
        <div className="fixed inset-0 z-50 flex items-center justify-end bg-slate-950/70 backdrop-blur-sm">
          <div
            className="w-full max-w-2xl h-full bg-slate-900 border-l border-slate-800 flex flex-col shadow-2xl animate-slide-left overflow-hidden"
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-slate-800/80 backdrop-blur-md z-10 p-6 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className="text-3xl bg-slate-700 p-2.5 rounded-xl">{selectedApi.categoryIcon}</span>
                <div>
                  <h2 className="text-xl font-bold text-slate-100">{selectedApi.name}</h2>
                  <p className="text-xs text-slate-400">{selectedApi.provider} &middot; {selectedApi.category}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setSelectedApi(null);
                  setLiveDemoResponse(null);
                  setLiveDemoError(null);
                }}
                className="text-slate-400 hover:text-slate-100 text-xl font-bold bg-slate-700 h-10 w-10 flex items-center justify-center rounded-full hover:bg-slate-600 transition-colors"
              >
                &times;
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-8 pb-12">
              {/* Quick Specs Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Authorization</span>
                  <span
                    className={`text-sm font-bold tracking-wide ${
                      selectedApi.auth === "NONE" ? "text-green-400" : "text-amber-400"
                    }`}
                  >
                    {selectedApi.auth === "NONE" ? "🔓 Open Access" : "🔑 Requires Key"}
                  </span>
                  <p className="text-xs text-slate-400 mt-1">{selectedApi.authDetails}</p>
                </div>
                <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Limits / Quotas</span>
                  <span className="text-sm font-bold text-slate-200">{selectedApi.limits}</span>
                  <p className="text-xs text-slate-400 mt-1">Free tier specifications.</p>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">Description</h3>
                <p className="text-sm text-slate-300 leading-relaxed bg-slate-800/30 p-4 rounded-xl border border-slate-800">
                  {selectedApi.description}
                </p>
              </div>

              {/* Integration Guide */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">How to use</h3>
                <ul className="text-sm text-slate-300 space-y-3 bg-slate-800/30 p-4 rounded-xl border border-slate-800">
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 font-bold">•</span>
                    <span>{selectedApi.howToUse}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 font-bold">•</span>
                    <span>{selectedApi.tips}</span>
                  </li>
                </ul>
              </div>

              {/* Code Snippet */}
              {selectedApi.curl && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">Integration Snippet</h3>
                    <button
                      onClick={() => copyToClipboard(selectedApi.curl!)}
                      className="text-xs text-purple-400 font-medium hover:text-purple-300 transition-colors"
                    >
                      Copy cURL
                    </button>
                  </div>
                  <pre className="text-xs font-mono bg-slate-950 p-4 rounded-xl border border-slate-800 text-pink-300 overflow-x-auto whitespace-pre-wrap break-all shadow-inner">
                    {selectedApi.curl}
                  </pre>
                </div>
              )}

              {/* Advanced Live Demo GUI */}
              {selectedApi.hasLiveDemo && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">Live API Terminal</h3>
                    <a
                      href={selectedApi.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-medium text-purple-400 hover:underline"
                    >
                      Visit Official Docs &rarr;
                    </a>
                  </div>

                  <div className="bg-slate-950 rounded-xl border border-slate-800 shadow-2xl overflow-hidden">
                    <div className="flex items-center justify-between bg-slate-800 px-4 py-2 border-b border-slate-700">
                      <div className="flex items-center gap-1.5">
                        <span className="h-3 w-3 rounded-full bg-red-500"></span>
                        <span className="h-3 w-3 rounded-full bg-yellow-500"></span>
                        <span className="h-3 w-3 rounded-full bg-green-500"></span>
                        <span className="text-xs text-slate-400 ml-2 font-mono">live_client.js</span>
                      </div>
                      <span className="text-xs font-mono text-slate-500">{selectedApi.method || "GET"}</span>
                    </div>

                    <div className="p-4 space-y-4">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-slate-900 text-xs text-slate-300 font-mono px-3 py-2.5 rounded-md border border-slate-800 overflow-x-auto whitespace-nowrap">
                          {selectedApi.liveDemoUrl}
                        </div>
                        <button
                          onClick={() => handleTryLive(selectedApi)}
                          disabled={liveDemoLoading}
                          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-md text-xs font-semibold disabled:opacity-50 flex items-center gap-2 whitespace-nowrap transition-colors shadow-lg shadow-purple-500/20"
                        >
                          {liveDemoLoading ? "Sending..." : "Send Req"}
                        </button>
                      </div>

                      {/* Terminal Output */}
                      {(liveDemoResponse || liveDemoLoading || liveDemoError) && (
                        <div className="bg-slate-900 rounded-md border border-slate-800 min-h-[150px] max-h-[300px] overflow-auto relative">
                          {liveDemoLoading && (
                            <div className="absolute inset-0 bg-slate-900/80 flex items-center justify-center space-y-2 flex-col">
                              <div className="animate-spin rounded-full h-6 w-6 border-2 border-t-purple-500 border-slate-700"></div>
                              <span className="text-xs text-slate-400 font-mono">Fetching through proxy...</span>
                            </div>
                          )}

                          {liveDemoError && (
                            <div className="p-4 text-xs font-mono text-red-400">
                              Error: {liveDemoError}
                            </div>
                          )}

                          {liveDemoResponse && (
                            <div className="p-4 text-xs font-mono text-green-300 relative group h-full">
                              <button
                                onClick={() => copyToClipboard(JSON.stringify(liveDemoResponse, null, 2))}
                                className="absolute top-2 right-2 text-xs text-slate-400 bg-slate-800 px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity hover:text-white"
                              >
                                Copy
                              </button>
                              <pre className="whitespace-pre-wrap break-all h-full">
                                {JSON.stringify(liveDemoResponse, null, 2)}
                              </pre>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
