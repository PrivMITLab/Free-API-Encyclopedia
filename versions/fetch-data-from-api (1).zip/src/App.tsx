import { useState, useMemo, useEffect, useRef } from "react";
import { API_DATA, CATEGORIES, getCategoryEmoji, formatAuth, formatFreeTier, type ApiEntry, type ApiCategory } from "./apiData";

type SortBy = "id" | "name" | "category";
type AuthFilter = "all" | "NONE" | "Key";
type CategoryFilter = "all" | ApiCategory;

function classNames(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text);
}

function CopyButton({ text, label = "Copy" }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => {
        copyToClipboard(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 1600);
      }}
      className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-slate-800 active:scale-95 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
    >
      {copied ? (
        <>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 6 9 17l-5-5" />
          </svg>
          Copied
        </>
      ) : (
        <>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
          </svg>
          {label}
        </>
      )}
    </button>
  );
}

function Badge({ children, color = "slate" }: { children: React.ReactNode; color?: string }) {
  const colors: Record<string, string> = {
    emerald: "bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-950/50 dark:text-emerald-300 dark:ring-emerald-400/30",
    amber: "bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-950/50 dark:text-amber-300 dark:ring-amber-400/30",
    blue: "bg-blue-50 text-blue-700 ring-blue-600/20 dark:bg-blue-950/50 dark:text-blue-300 dark:ring-blue-400/30",
    violet: "bg-violet-50 text-violet-700 ring-violet-600/20 dark:bg-violet-950/50 dark:text-violet-300 dark:ring-violet-400/30",
    slate: "bg-slate-50 text-slate-700 ring-slate-600/10 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700",
    rose: "bg-rose-50 text-rose-700 ring-rose-600/20 dark:bg-rose-950/50 dark:text-rose-300 dark:ring-rose-400/30",
  };
  
  return (
    <span className={classNames("inline-flex items-center rounded-md px-2 py-1 text-xs font-medium ring-1 ring-inset", colors[color] || colors.slate)}>
      {children}
    </span>
  );
}

function Modal({ api, onClose }: { api: ApiEntry | null; onClose: () => void }) {
  const [demoData, setDemoData] = useState<any>(null);
  const [demoLoading, setDemoLoading] = useState(false);
  const [demoError, setDemoError] = useState<string | null>(null);
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (api) {
      document.body.style.overflow = "hidden";
      setDemoData(null);
      setDemoError(null);
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [api]);

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    function handleClick(e: MouseEvent) {
      if (modalRef.current && e.target === modalRef.current) onClose();
    }
    if (api) {
      window.addEventListener("keydown", handleKey);
      window.addEventListener("click", handleClick);
    }
    return () => {
      window.removeEventListener("keydown", handleKey);
      window.removeEventListener("click", handleClick);
    };
  }, [api, onClose]);

  const runLiveDemo = async () => {
    if (!api?.baseUrl || !api.demoEndpoint) return;
    
    setDemoLoading(true);
    setDemoError(null);
    setDemoData(null);

    try {
      const url = new URL(api.baseUrl + api.demoEndpoint);
      if (api.demoParams) {
        Object.entries(api.demoParams).forEach(([k, v]) => url.searchParams.set(k, v));
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(url.toString(), {
        method: api.demoMethod || "GET",
        headers: {
          "Accept": "application/json",
          ...(api.demoHeaders || {}),
        },
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get("content-type") || "";
      if (contentType.includes("application/json")) {
        const data = await response.json();
        setDemoData(data);
      } else {
        const text = await response.text();
        setDemoData({ _text: text.slice(0, 2000) });
      }
    } catch (err: any) {
      setDemoError(err.name === "AbortError" ? "Request timed out" : err.message || "Failed to fetch");
    } finally {
      setDemoLoading(false);
    }
  };

  if (!api) return null;

  const auth = formatAuth(api.auth);
  const tier = formatFreeTier(api.freeTier);

  return (
    <div ref={modalRef} className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-950/70 p-4 backdrop-blur-sm">
      <div className="my-8 w-full max-w-4xl animate-in fade-in slide-in-from-bottom-4 rounded-3xl bg-white shadow-2xl ring-1 ring-slate-900/5 dark:bg-slate-900 dark:ring-white/10">
        <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-slate-200 bg-white/80 p-6 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-900/80 sm:p-8">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1.5">
                <span className="text-lg">{getCategoryEmoji(api.category)}</span>
                {api.category}
              </span>
              <span>•</span>
              <span>{api.provider}</span>
            </div>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
              {api.name}
            </h2>
            <p className="mt-2 text-slate-600 dark:text-slate-300">{api.description}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Badge color={auth.color}>
                <span className="mr-1">{auth.icon}</span>
                {auth.label}
              </Badge>
              <Badge color={tier.color}>{tier.label}</Badge>
              <Badge color={api.cors === "Yes" ? "emerald" : api.cors === "Partial" ? "amber" : "rose"}>
                CORS: {api.cors}
              </Badge>
              <Badge color="slate">#{api.id}</Badge>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-500 transition hover:bg-slate-200 hover:text-slate-700 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700 dark:hover:text-slate-200"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="grid gap-8 p-6 sm:grid-cols-2 sm:p-8">
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Auth & Limits</h3>
              <div className="mt-3 rounded-2xl bg-slate-50 p-4 dark:bg-slate-800/50">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium text-slate-900 dark:text-slate-100">Authentication</div>
                    <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">
                      {api.auth === "NONE" ? "No login/key required. Great for testing." : 
                       api.auth === "Key" ? "API key required. Sign up at provider website." :
                       "OAuth login required."}
                    </div>
                  </div>
                  <Badge color={auth.color}>{auth.label}</Badge>
                </div>
                <div className="mt-4 h-px bg-slate-200 dark:bg-slate-700" />
                <div className="mt-4 flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium text-slate-900 dark:text-slate-100">Rate Limits</div>
                    <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">{api.limits}</div>
                    <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">{api.rateLimitDetails}</div>
                  </div>
                </div>
                {api.requiresSignup && (
                  <>
                    <div className="mt-4 h-px bg-slate-200 dark:bg-slate-700" />
                    <div className="mt-4 text-xs text-amber-700 dark:text-amber-300">
                      ⚠️ Requires free account signup to get API key
                    </div>
                  </>
                )}
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Use Cases</h3>
              <div className="mt-3 flex flex-wrap gap-2">
                {api.useCases.map(use => (
                  <span key={use} className="rounded-full bg-violet-50 px-3 py-1 text-sm text-violet-700 ring-1 ring-inset ring-violet-200 dark:bg-violet-950/50 dark:text-violet-300 dark:ring-violet-800">
                    {use}
                  </span>
                ))}
              </div>
            </div>

            {api.whyUse && (
              <div>
                <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Why use this API?</h3>
                <p className="mt-3 rounded-2xl bg-emerald-50 p-4 text-sm leading-relaxed text-emerald-900 ring-1 ring-inset ring-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-100 dark:ring-emerald-900/50">
                  {api.whyUse}
                </p>
              </div>
            )}

            <div className="flex flex-wrap gap-3">
              <a href={api.website} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800 active:scale-95 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100">
                Visit Website
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M7 17 17 7" /><path d="M7 7h10v10" />
                </svg>
              </a>
              <a href={api.docs} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-medium text-slate-700 ring-1 ring-inset ring-slate-300 transition hover:bg-slate-50 active:scale-95 dark:bg-slate-800 dark:text-slate-200 dark:ring-slate-700 dark:hover:bg-slate-700">
                Read Docs
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
                </svg>
              </a>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Example Request</h3>
                {api.exampleRequest && <CopyButton text={api.exampleRequest} />}
              </div>
              <pre className="mt-3 overflow-x-auto rounded-2xl bg-slate-950 p-4 text-xs leading-relaxed text-slate-100 dark:bg-black">
                <code>{api.exampleRequest || "No example available"}</code>
              </pre>
            </div>

            {api.tips && api.tips.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Pro Tips</h3>
                <ul className="mt-3 space-y-2">
                  {api.tips.map((tip, i) => (
                    <li key={i} className="flex gap-2 text-sm text-slate-600 dark:text-slate-300">
                      <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-violet-500" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="rounded-2xl bg-slate-50 p-5 dark:bg-slate-800/50">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">How to use</h3>
              <div className="mt-3 space-y-3 text-sm text-slate-600 dark:text-slate-300">
                <p>1. Read the provider docs and create an account if a key is required.</p>
                <p>2. Store secrets in environment variables or serverless functions (never in client code).</p>
                <p>3. Implement caching to respect rate limits (e.g., 30 min TTL) and add retries with backoff.</p>
                <p>4. Handle errors gracefully; show fallback UI when APIs are down.</p>
              </div>
            </div>
          </div>
        </div>

        {api.baseUrl && api.demoEndpoint && (
          <div className="border-t border-slate-200 bg-slate-50/50 p-6 dark:border-slate-800 dark:bg-slate-900/50 sm:p-8">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">Live Demo</h3>
              <div className="flex gap-2">
                <button
                  onClick={runLiveDemo}
                  disabled={demoLoading}
                  className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-violet-500 disabled:opacity-60 active:scale-95"
                >
                  {demoLoading ? (
                    <>
                      <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                      </svg>
                      Fetching...
                    </>
                  ) : (
                    <>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                      </svg>
                      Try live
                    </>
                  )}
                </button>
                {demoData && <CopyButton text={JSON.stringify(demoData, null, 2)} label="Copy JSON" />}
              </div>
            </div>

            <div className="mt-4 rounded-2xl bg-slate-950 p-4 dark:bg-black">
              {demoLoading && (
                <div className="flex items-center justify-center py-12 text-slate-400">
                  <svg className="animate-spin mr-3" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                  </svg>
                  Fetching real data from API...
                </div>
              )}
              {demoError && (
                <div className="rounded-xl bg-rose-950/50 p-4 text-sm text-rose-200 ring-1 ring-rose-900">
                  ❌ Error: {demoError}
                  <div className="mt-2 text-xs opacity-80">Note: Some APIs block browser requests (CORS). Try the cURL command instead.</div>
                </div>
              )}
              {demoData && (
                <div className="relative">
                  <pre className="max-h-[420px] overflow-auto text-xs leading-relaxed text-slate-100">
                    <code>{JSON.stringify(demoData, null, 2)}</code>
                  </pre>
                  <div className="absolute right-3 top-3">
                    <CopyButton text={JSON.stringify(demoData)} label="Copy response" />
                  </div>
                </div>
              )}
              {!demoLoading && !demoError && !demoData && (
                <div className="py-12 text-center text-sm text-slate-400">
                  Click "Try live" to fetch real data from {api.name}. No API key needed for this demo.
                </div>
              )}
            </div>
            <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
              URL: <code className="rounded bg-slate-200 px-1.5 py-0.5 font-mono text-[11px] dark:bg-slate-800 dark:text-slate-300">{api.baseUrl}{api.demoEndpoint}{api.demoParams ? "?" + new URLSearchParams(api.demoParams).toString() : ""}</code>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("all");
  const [authFilter, setAuthFilter] = useState<AuthFilter>("all");
  const [sortBy, setSortBy] = useState<SortBy>("id");
  const [selected, setSelected] = useState<ApiEntry | null>(null);
  const [favorites, setFavorites] = useState<number[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("api-favorites") || "[]");
    } catch { return []; }
  });

  useEffect(() => {
    localStorage.setItem("api-favorites", JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (id: number) => {
    setFavorites(f => f.includes(id) ? f.filter(x => x !== id) : [...f, id]);
  };

  const filtered = useMemo(() => {
    let list = [...API_DATA];
    
    if (query) {
      const q = query.toLowerCase();
      list = list.filter(api =>
        api.name.toLowerCase().includes(q) ||
        api.provider.toLowerCase().includes(q) ||
        api.description.toLowerCase().includes(q) ||
        api.useCases.some(u => u.toLowerCase().includes(q))
      );
    }
    
    if (categoryFilter !== "all") {
      list = list.filter(api => api.category === categoryFilter);
    }
    
    if (authFilter !== "all") {
      list = list.filter(api => api.auth === authFilter);
    }

    list.sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name);
      if (sortBy === "category") return a.category.localeCompare(b.category) || a.name.localeCompare(b.name);
      return a.id - b.id;
    });

    return list;
  }, [query, categoryFilter, authFilter, sortBy]);

  const stats = useMemo(() => {
    const noAuth = API_DATA.filter(a => a.auth === "NONE").length;
    const free = API_DATA.filter(a => a.freeTier === "Free").length;
    return { total: API_DATA.length, noAuth, free };
  }, []);

  return (
    <div className="min-h-screen bg-white text-slate-900 antialiased dark:bg-slate-950 dark:text-slate-100">
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />
        <div className="absolute left-1/2 top-0 h-[600px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-300/20 blur-[120px] dark:bg-violet-900/20" />
      </div>

      <header className="sticky top-0 z-30 border-b border-slate-200/60 bg-white/70 backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-950/70">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-600/20">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 18 22 12 16 6" /><path d="M8 6 2 12 8 18" />
              </svg>
            </div>
            <div className="min-w-0">
              <div className="truncate text-lg font-semibold tracking-tight sm:text-xl">Free API Encyclopedia</div>
              <div className="hidden text-xs text-slate-500 dark:text-slate-400 sm:block">325+ free APIs with real-time demos • Updated March 2026</div>
            </div>
          </div>
          <div className="hidden items-center gap-3 sm:flex">
            <Badge color="emerald">{stats.noAuth} No Auth</Badge>
            <Badge color="violet">{stats.free} Free Forever</Badge>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-[2rem] border border-slate-200 bg-gradient-to-br from-violet-50 via-white to-indigo-50 p-8 shadow-sm dark:border-slate-800 dark:from-violet-950/20 dark:via-slate-900 dark:to-indigo-950/20 sm:p-12">
          <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-violet-400/20 blur-[100px]" />
          <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-indigo-400/20 blur-[100px]" />
          <div className="relative">
            <div className="inline-flex items-center gap-2 rounded-full bg-white/60 px-3 py-1 text-xs font-medium text-slate-600 ring-1 ring-inset ring-slate-200 backdrop-blur dark:bg-slate-900/60 dark:text-slate-300 dark:ring-slate-800">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              Live data • Updated for 2026
            </div>
            <h1 className="mt-6 max-w-3xl text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl lg:text-5xl">
              The definitive collection of <span className="bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">325+ free APIs</span>
            </h1>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-slate-600 dark:text-slate-300 sm:text-lg">
              Every API tested with real limits, auth requirements, live demos, and code samples. Perfect for prototypes, side projects, and learning.
            </p>
            
            <div className="mt-8 grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl bg-white/70 p-4 ring-1 ring-slate-200 backdrop-blur dark:bg-slate-900/70 dark:ring-slate-800">
                <div className="text-2xl font-semibold text-slate-900 dark:text-white">{stats.total}+</div>
                <div className="text-sm text-slate-600 dark:text-slate-400">Total APIs catalogued</div>
              </div>
              <div className="rounded-2xl bg-white/70 p-4 ring-1 ring-slate-200 backdrop-blur dark:bg-slate-900/70 dark:ring-slate-800">
                <div className="text-2xl font-semibold text-emerald-600 dark:text-emerald-400">{stats.noAuth}</div>
                <div className="text-sm text-slate-600 dark:text-slate-400">No signup required</div>
              </div>
              <div className="rounded-2xl bg-white/70 p-4 ring-1 ring-slate-200 backdrop-blur dark:bg-slate-900/70 dark:ring-slate-800">
                <div className="text-2xl font-semibold text-violet-600 dark:text-violet-400">{stats.free}</div>
                <div className="text-sm text-slate-600 dark:text-slate-400">Completely free forever</div>
              </div>
            </div>
          </div>
        </div>

        <div className="sticky top-[73px] z-20 -mx-4 mt-8 border-y border-slate-200 bg-white/80 px-4 py-4 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/80 sm:mx-0 sm:rounded-2xl sm:border sm:px-5">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <svg className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
              </svg>
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search APIs, providers, or use cases..."
                className="h-11 w-full rounded-xl border border-slate-300 bg-white pl-11 pr-4 text-sm text-slate-900 placeholder-slate-500 outline-none ring-violet-500/20 transition focus:border-violet-500 focus:ring-4 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:placeholder-slate-400"
              />
              {query && (
                <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-300">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 6 6 18M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value as CategoryFilter)} className="h-11 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="all">All categories</option>
                {CATEGORIES.map(c => (
                  <option key={c.id} value={c.id}>{c.emoji} {c.id}</option>
                ))}
              </select>

              <select value={authFilter} onChange={e => setAuthFilter(e.target.value as AuthFilter)} className="h-11 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="all">All auth types</option>
                <option value="NONE">✓ No auth</option>
                <option value="Key">🔑 API key</option>
              </select>

              <select value={sortBy} onChange={e => setSortBy(e.target.value as SortBy)} className="h-11 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="id">Sort by ID</option>
                <option value="name">Sort by name</option>
                <option value="category">Sort by category</option>
              </select>
            </div>
          </div>
        </div>

        <div className="mt-8 flex items-center justify-between">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Showing <span className="font-medium text-slate-900 dark:text-slate-100">{filtered.length}</span> APIs
            {query && <> for "<span className="font-medium">{query}</span>"</>}
          </p>
          {favorites.length > 0 && (
            <button onClick={() => setFavorites([])} className="text-xs text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              Clear {favorites.length} favorites
            </button>
          )}
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map(api => {
            const auth = formatAuth(api.auth);
            const tier = formatFreeTier(api.freeTier);
            const isFav = favorites.includes(api.id);

            return (
              <article
                key={api.id}
                className="group relative flex flex-col rounded-[1.5rem] border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-lg hover:shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:hover:shadow-black/20"
              >
                <button
                  onClick={() => toggleFavorite(api.id)}
                  className={classNames("absolute right-4 top-4 z-10 flex h-8 w-8 items-center justify-center rounded-full transition", isFav ? "bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400" : "bg-slate-100 text-slate-400 hover:bg-slate-200 hover:text-slate-600 dark:bg-slate-800 dark:text-slate-500 dark:hover:bg-slate-700 dark:hover:text-slate-300")}
                  aria-label="Favorite"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill={isFav ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                  </svg>
                </button>

                <div className="flex items-start gap-3">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-slate-100 text-2xl dark:bg-slate-800">
                    {getCategoryEmoji(api.category)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="pr-8 text-base font-semibold leading-tight text-slate-900 dark:text-white">
                        {api.name}
                      </h3>
                      <div className="shrink-0 text-xs font-medium text-slate-400">#{api.id}</div>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                      <span className="truncate">{api.provider}</span>
                      <span>•</span>
                      <span className="truncate">{api.category}</span>
                    </div>
                  </div>
                </div>

                <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                  {api.description}
                </p>

                <div className="mt-4 flex flex-wrap gap-1.5">
                  <Badge color={auth.color}>
                    <span className="mr-1">{auth.icon}</span>
                    {auth.label}
                  </Badge>
                  <Badge color={tier.color}>{tier.label}</Badge>
                  <Badge color="slate">{api.limits}</Badge>
                </div>

                <div className="mt-4 flex flex-wrap gap-1">
                  {api.useCases.slice(0, 3).map(u => (
                    <span key={u} className="rounded-md bg-slate-100 px-2 py-1 text-[11px] text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                      {u}
                    </span>
                  ))}
                  {api.useCases.length > 3 && (
                    <span className="rounded-md bg-slate-100 px-2 py-1 text-[11px] text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                      +{api.useCases.length - 3}
                    </span>
                  )}
                </div>

                <div className="mt-5 flex items-center gap-2">
                  <button
                    onClick={() => setSelected(api)}
                    className="flex-1 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800 active:scale-[0.98] dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
                  >
                    View details
                  </button>
                  <a
                    href={api.website}
                    target="_blank"
                    rel="noreferrer"
                    className="flex h-[42px] w-[42px] items-center justify-center rounded-xl border border-slate-300 text-slate-600 transition hover:bg-slate-50 active:scale-95 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
                    aria-label="Visit website"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
                    </svg>
                  </a>
                </div>
              </article>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="mt-16 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
              </svg>
            </div>
            <h3 className="mt-4 text-lg font-medium text-slate-900 dark:text-white">No APIs found</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Try adjusting your filters or search term</p>
            <button onClick={() => { setQuery(""); setCategoryFilter("all"); setAuthFilter("all"); }} className="mt-4 text-sm font-medium text-violet-600 hover:text-violet-500 dark:text-violet-400">
              Clear all filters
            </button>
          </div>
        )}

        <div className="mt-20 grid gap-6 rounded-[2rem] border border-slate-200 bg-slate-50 p-8 dark:border-slate-800 dark:bg-slate-900/50 sm:grid-cols-3">
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">For Developers</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li>• All APIs tested in March 2026</li>
              <li>• Real rate limits and auth info</li>
              <li>• Working code examples</li>
              <li>• Live demos (where CORS allows)</li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Pro Tips</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li>• Cache responses (30 min TTL)</li>
              <li>• Never expose keys in client code</li>
              <li>• Use serverless functions for secrets</li>
              <li>• Handle errors gracefully</li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Get Started</h4>
            <div className="mt-3 space-y-3">
              <a href="https://github.com" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-sm font-medium text-violet-600 hover:text-violet-500 dark:text-violet-400">
                Star on GitHub
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M7 17 17 7" /><path d="M7 7h10v10" />
                </svg>
              </a>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Made with ❤️ for developers. Data refreshed monthly.
              </p>
            </div>
          </div>
        </div>
      </main>

      <Modal api={selected} onClose={() => setSelected(null)} />
    </div>
  );
}
