# 📖 Free API Encyclopedia - Complete Details Guide

## 🇮🇳 Hindi Guide - Is App Ke Sab Features Aur API Kaise Add Karein

---

## 🎯 App Overview

**Free API Encyclopedia** ek comprehensive web application hai jo 400+ free APIs ka detailed information provide karta hai. Har API ke saath live demo, CORS proxy support, aur copy-paste ready cURL commands available hain.

---

## 🚀 App Features - Detailed Breakdown

### 🔍 1. Smart Search System

App mein ek powerful search bar hai jo APIs ko find karne ke liye use hota hai.

**Search karta hai:**
- API ke name se (e.g., "JSONPlace", "CoinGecko")
- Provider name se (e.g., "Google", "Typicode", "NASA")
- Description se (e.g., "fake data", "weather", "crypto")
- Use cases se (e.g., "testing", "AI", "gaming")

**Kaise use karein:**
1. Top search bar mein type karo
2. Real-time results dekho
3. Clean search ke liye "×" button dabakar clear karo

**Keyboard shortcuts:**
- `Ctrl + /` se search focus karo
- `Escape` se search clear karo

---

### 🎭 2. Category Filters

App mein 7 categories hain, har ek unique emoji ke saath:

| Emoji | Category | Example APIs |
|-------|----------|--------------|
| 🤖 | AI & Agentic | Gemini, Groq, HuggingFace |
| 🧪 | Testing & Placeholder | JSONPlaceholder, ReqRes, FakeStore |
| 💰 | Finance & Crypto | CoinGecko, Coinbase, Alpha Vantage |
| 🎮 | Gaming & Esports | Chess.com, Steam, RAWG |
| 🎵 | Music & Multimedia | Spotify, YouTube, OMDb |
| 🛠️ | DevTools & Infrastructure | GitHub, Firebase, Supabase |
| 🏛️ | Gov, Science & World | NASA, Wikipedia, Weather |

**Filter kaise use karein:**
1. Category buttons dabakar filter karo
2. Multiple categories select kar sakte ho
3. "All" dabakar sab dekho

---

### 🔐 3. Auth Type Filters

APIs ko authentication requirement ke hisaab se filter karo:

| Filter | Meaning | Example |
|--------|---------|---------|
| All | Sab APIs | - |
| No Auth | Bina login/key ke kaam kare | JSONPlaceholder, Dog CEO API |
| API Key | Key chahiye | CoinGecko, OMDb |
| OAuth | OAuth login chahiye | Google, GitHub |
| Login Required | Account/signup mandatory | Most paid tiers |

---

### ❤️ 4. Favorites System

Apni favorite APIs ko save karo for quick access.

**Favorites add kaise karein:**
1. Kisi bhi API card pe ❤️ icon pe click karo
2. Icon red ho jayega = favorite added
3. "Favorites" filter select karo sirf saved APIs dekhe

**Features:**
- Browser localStorage mein save hota hai
- Page refresh pe bhi persist karta hai
- Favorites count header mein show hota hai

**Favorites ko export kaise karein:**
- Currently JSON format mein manually copy kar sakte ho
- Future: CSV/JSON export option aayega

---

### 📊 5. Sort Options

APIs ko different ways se sort kar sakte ho:

| Option | Description |
|--------|-------------|
| Default (ID) | Original order (1, 2, 3...) |
| Name (A-Z) | Alphabetical order |
| Name (Z-A) | Reverse alphabetical |
| Category | Category-wise group |

**Kaise use karein:**
1. "Sort by" dropdown select karo
2. Instant sorting dekho

---

### 🎫 6. API Details Modal

Kisi bhi API pe click karne par ek detailed modal khulti hai jismein full information hoti hai.

#### Modal Sections:

##### 🏷️ Basic Info
- API Name
- Provider/Company
- Category with emoji
- Unique ID

##### 🔑 Authentication Info
```
Auth Type: API Key
Free Tier: ✅ Free Forever
Requires Signup: ⚠️ Yes - Create free account at provider
```

##### 📈 Rate Limits
```
Daily: 10,000 requests
Monthly: 100,000 requests
Rate Limit: 10 requests/second
```

##### 📝 Description
API ka kya karta hai, kaise kaam karta hai.

##### 💡 Use Cases
List of common use cases:
- UI prototyping
- Mock data generation
- Testing integrations
- Learning APIs

##### 🎯 Why Use This API?
Benefits aur advantages:
- "Perfect for rapid prototyping"
- "No authentication needed for testing"
- "High rate limits for development"

##### 💡 Pro Tips
Expert recommendations:
- "Cache responses for 30 minutes"
- "Use pagination for large datasets"
- "Store keys in environment variables"

##### 🌐 Live Demo Section (Most Important!)
```
┌─────────────────────────────────────────────────────┐
│ 📡 Live Demo                                        │
│                                                      │
│ Endpoint: https://api.coingecko.com/...            │
│ Method: GET                                         │
│ Params: { vs_currency: "usd", order: "gecko_desc" }│
│                                                      │
│ CORS Proxy: [Direct] [AllOrigins] [corsproxy.io]  │
│                                                      │
│ [Try Live]                                          │
│                                                      │
│ Response Preview:                                   │
│ {                                                   │
│   "bitcoin": { "usd": 67000 },                     │
│   "ethereum": { "usd": 3500 }                       │
│ }                                                   │
└─────────────────────────────────────────────────────┘
```

##### 🖥️ cURL Example
Production-ready cURL command:
```bash
curl -X GET "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=gecko_desc" \
  -H "Accept: application/json"
```

---

### 🌐 7. CORS Proxy Toggle System

Ye app ka most powerful feature hai! Browser requests ke liye CORS issues ko handle karta hai.

#### Problem Explained:
Jab aap browser se API call karte ho, toh API server request ko block kar sakta hai (CORS policy). Ye development ke liye frustrating ho sakta hai.

#### Solution:
App mein 3 proxy options hain:

| Option | URL | Best For |
|--------|-----|----------|
| Direct | (none) | Public/CORS-enabled APIs |
| AllOrigins | `https://api.allorigins.win/raw?url=` | Most APIs |
| corsproxy.io | `https://corsproxy.io/?` | Fallback |

#### Kaise Use Karein:
1. Modal mein "CORS Proxy" dropdown dekho
2. "Direct" select karo (default)
3. "Try Live" dabako request karo
4. Agar CORS error aaye, toh proxy change karo:
   - AllOrigins try karo
   - Still fail? corsproxy.io try karo
5. Jo work Kare, woh select karo aur use karo

#### Visual Indicators:
- ✅ **Success**: Green checkmark + JSON response
- ⚠️ **CORS Error**: Yellow warning + proxy suggestion buttons
- ❌ **Network Error**: Red error + retry options
- ⏱️ **Timeout**: Orange timeout + slow connection message

---

### 📋 8. Copy Functions

Har important information ko copy karne ke buttons available hain:

| Copy Type | Description |
|-----------|-------------|
| Copy cURL | Full cURL command copy karein |
| Copy JSON | Live demo response copy karein |
| Copy URL | API endpoint URL copy karein |

**Keyboard shortcuts:**
- Modal open hone par auto-select nahi hota
- Button pe click se clipboard mein save hota hai
- Success message toast ke through show hota hai

---

### 🌙 9. Dark Mode

App mein dark mode support hai.

**Kaise use karein:**
- Header mein "🌙" icon pe click karo
- Browser preference auto-detect karta hai
- Selection localStorage mein save hota hai

**Dark Mode Features:**
- Reduced eye strain
- Better battery on OLED screens
- Modern look

---

### 📱 10. Responsive Design

App completely responsive hai - mobile, tablet, aur desktop sab par achha dikhta hai.

| Device | Layout |
|--------|--------|
| Mobile (<640px) | 1 column, stacked filters |
| Tablet (640-1024px) | 2 columns |
| Desktop (>1024px) | 3-4 columns, full sidebar |

---

## 🔧 API Adding Guide - Kaise Naye APIs Add Karein

### Method 1: Manual Addition (Recommended for Beginners)

#### Step 1: File Open Karein
```bash
src/apiData.ts
```

#### Step 2: New API Entry Add Karein
Niche diye gaye format mein API add karo:

```typescript
{
  id: 401,
  name: "My New API",
  provider: "My Company",
  category: "🧪",
  auth: "NONE",
  limits: "1,000 req/day",
  description: "API ka kya karta hai, short description.",
  website: "https://myapi.com",
  docs: "https://myapi.com/docs",
  baseUrl: "https://api.myapi.com/v1",
  demoEndpoint: "/users?_limit=3",
  demoMethod: "GET",
  demoParams: {},
  freeTier: "Free Forever",
  requiresSignup: false,
  cors: "Yes",
  rateLimitDetails: "1,000 requests/day, 10/sec",
  useCases: [
    "Testing aur prototyping",
    "Mock data generation",
    "Learning purpose"
  ],
  whyUse: "Is API ka kya fayda hai developers ke liye.",
  tips: [
    "Response cache karo for better performance",
    "Pagination use karo large datasets ke liye"
  ],
  exampleRequest: `curl -X GET "https://api.myapi.com/v1/users" -H "Accept: application/json"`
}
```

#### Step 3: Format Guidelines

**Category Emoji Options:**
- 🤖 = AI & Agentic
- 🧪 = Testing & Placeholder
- 💰 = Finance & Crypto
- 🎮 = Gaming & Esports
- 🎵 = Music & Multimedia
- 🛠️ = DevTools & Infrastructure
- 🏛️ = Gov, Science & World

**Auth Types:**
- `NONE` = No authentication required
- `KEY` = API Key required
- `OAuth` = OAuth authentication needed
- `LOGIN_REQUIRED` = Login/signup mandatory

**CORS Values:**
- `Yes` = Browser se directly accessible
- `No` = CORS blocked, proxy chahiye
- `Partial` = Kuch endpoints work karte hain

**Limits Format:**
- Daily: "1,000 req/day"
- Monthly: "100,000 req/mo"
- Per minute: "10 RPM"
- Per second: "100 RPS"
- No limit: "❌ No Limit"

---

### Method 2: Batch Addition (For Power Users)

Agar aapko ek saath multiple APIs add karni hain, toh:

```typescript
// Array of new APIs
const NEW_APIS = [
  { id: 401, name: "API 1", ... },
  { id: 402, name: "API 2", ... },
  { id: 403, name: "API 3", ... },
];

// Merge with existing
const ALL_APIS = [...API_DATA, ...NEW_APIS];
```

---

### Method 3: External JSON File (Advanced)

#### Step 1: JSON File Create Karein
`data/apis.json`:

```json
[
  {
    "id": 401,
    "name": "My API",
    "provider": "My Company",
    "category": "🧪",
    "auth": "NONE",
    "limits": "1,000/day",
    "description": "Description here",
    ...
  }
]
```

#### Step 2: Fetch in App
```typescript
// App.tsx mein
const [apis, setApis] = useState<API[]>([]);

useEffect(() => {
  fetch('/data/apis.json')
    .then(res => res.json())
    .then(data => setApis([...API_DATA, ...data]))
    .catch(err => console.error(err));
}, []);
```

---

## 📝 Complete Field Reference

Har API entry mein ye fields hain:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | number | ✅ | Unique identifier (400+, 401, etc.) |
| `name` | string | ✅ | API ka official name |
| `provider` | string | ✅ | Company/organization name |
| `category` | string | ✅ | Category emoji |
| `auth` | string | ✅ | Authentication type |
| `limits` | string | ✅ | Free tier rate limits |
| `description` | string | ✅ | Short description (1-2 sentences) |
| `website` | string | ❌ | Main website URL |
| `docs` | string | ❌ | Documentation URL |
| `baseUrl` | string | ❌ | API base URL |
| `demoEndpoint` | string | ❌ | Endpoint for live demo |
| `demoMethod` | string | ❌ | GET/POST/PUT etc. |
| `demoParams` | object | ❌ | Query params for demo |
| `freeTier` | string | ❌ | Free tier details |
| `requiresSignup` | boolean | ❌ | Need account? |
| `cors` | string | ❌ | CORS status |
| `browserSafe` | boolean | ❌ | Works in browser? |
| `rateLimitDetails` | string | ❌ | Detailed rate limits |
| `useCases` | string[] | ❌ | Common use cases |
| `whyUse` | string | ❌ | Why developers use this |
| `tips` | string[] | ❌ | Pro tips |
| `exampleRequest` | string | ❌ | cURL example |

---

## ✅ API Entry Template (Copy-Paste Ready)

```typescript
{
  id: 999,
  name: "",
  provider: "",
  category: "🧪",
  auth: "NONE",
  limits: "",
  description: "",
  website: "",
  docs: "",
  baseUrl: "",
  demoEndpoint: "",
  demoMethod: "GET",
  demoParams: {},
  freeTier: "",
  requiresSignup: false,
  cors: "Yes",
  browserSafe: true,
  rateLimitDetails: "",
  useCases: [],
  whyUse: "",
  tips: [],
  exampleRequest: ""
}
```

---

## 🎯 Quick Examples

### Example 1: Simple Public API (No Auth)

```typescript
{
  id: 401,
  name: "Cat Facts",
  provider: "Cat Facts API",
  category: "🧪",
  auth: "NONE",
  limits: "❌ No Limit",
  description: "Random cat facts for testing and fun.",
  website: "https://catfact.ninja",
  docs: "https://catfact.ninja/api",
  baseUrl: "https://catfact.ninja",
  demoEndpoint: "/fact",
  demoMethod: "GET",
  demoParams: {},
  freeTier: "Free Forever",
  requiresSignup: false,
  cors: "Yes",
  browserSafe: true,
  rateLimitDetails: "No rate limit",
  useCases: ["Testing", "Demo data", "Learning"],
  whyUse: "Simple, no-auth API for testing",
  tips: ["Great for beginners"],
  exampleRequest: 'curl -X GET "https://catfact.ninja/fact"'
}
```

### Example 2: API Key Required API

```typescript
{
  id: 402,
  name: "Weather API",
  provider: "OpenWeather",
  category: "🏛️",
  auth: "KEY",
  limits: "1,000 req/day (Free)",
  description: "Global weather data and forecasts.",
  website: "https://openweathermap.org",
  docs: "https://openweathermap.org/api",
  baseUrl: "https://api.openweathermap.org/data/2.5",
  demoEndpoint: "/weather?q=London&appid=YOUR_KEY",
  demoMethod: "GET",
  demoParams: { "q": "London", "appid": "YOUR_KEY" },
  freeTier: "1,000 req/day",
  requiresSignup: true,
  cors: "Yes",
  browserSafe: true,
  rateLimitDetails: "60 calls/minute",
  useCases: ["Weather apps", "Travel apps", "Widgets"],
  whyUse: "Accurate global weather data",
  tips: ["Get free API key from website", "Cache responses"],
  exampleRequest: 'curl -X GET "https://api.openweathermap.org/data/2.5/weather?q=London&appid=YOUR_KEY"'
}
```

### Example 3: OAuth/API with Complex Auth

```typescript
{
  id: 403,
  name: "Google Drive",
  provider: "Google",
  category: "🛠️",
  auth: "OAuth",
  limits: "Various by quota",
  description: "File storage and management API.",
  website: "https://developers.google.com/drive",
  docs: "https://developers.google.com/drive/api/v3",
  baseUrl: "https://www.googleapis.com/drive/v3",
  demoEndpoint: "/files",
  demoMethod: "GET",
  demoParams: {},
  freeTier: "Free tier available",
  requiresSignup: true,
  cors: "No",
  browserSafe: false,
  rateLimitDetails: "Varies by quota",
  useCases: ["File storage", "Backup", "Collaboration"],
  whyUse: "Enterprise-grade file management",
  tips: ["Use OAuth 2.0", "Handle refresh tokens"],
  exampleRequest: 'curl -X GET "https://www.googleapis.com/drive/v3/files" -H "Authorization: Bearer YOUR_TOKEN"'
}
```

---

## 🔍 Testing Your Added API

Jab aap naya API add karo, toh test karne ke liye:

### 1. Check for Errors
```bash
npm run build
```

### 2. Test in Browser
1. App open karo
2. Search mein API ka name type karo
3. API card pe click karo
4. "Try Live" dabako test karo

### 3. Test All Proxy Options
- Direct: Test karein
- AllOrigins: Test karein  
- corsproxy.io: Test karein
- cURL: Terminal mein paste karo

### 4. Check All Fields
- Description sahi dikhe
- cURL copy ho
- JSON response show ho
- Links work karein

---

## 🚨 Common Issues Aur Solutions

### Issue 1: CORS Error
```
❌ Error: Network error or CORS blocked
```

**Solution:**
1. CORS Proxy = AllOrigins try karo
2. Agar fail ho, corsproxy.io try karo
3. Last resort: cURL use karo

### Issue 2: Invalid Endpoint
```
❌ Error: 404 Not Found
```

**Solution:**
1. demoEndpoint check karo
2. baseUrl correct hai check karo
3. API docs dekho

### Issue 3: Timeout
```
⏱️ Request Timeout
```

**Solution:**
1. API server slow ho sakta hai
2. Thoda wait karo aur retry karo
3. Proxy change karo

### Issue 4: JSON Parse Error
```
❌ Error: Invalid JSON
```

**Solution:**
1. API valid JSON return kar raha hai check karo
2. Response format docs mein dekho

---

## 🎓 Best Practices

### API Selection Ke Liye:
1. **Open Source/community maintained** APIs choose karo
2. **Active documentation** wale APIs prefer karo
3. **Recent updates** wali APIs select karo
4. **Clear rate limits** wali APIs best hain

### Testing Ke Liye:
1. **Small requests** se start karo
2. **Error handling** hamesha add karo
3. **Caching** implement karo
4. **Fallback** options ready rakho

### Production Ke Liye:
1. **API keys** kabhi client-side mein na rakho
2. **Environment variables** use karo
3. **Rate limiting** apne app mein implement karo
4. **Caching** use karo free tier maximize karne ke liye

---

## 📚 Additional Resources

### Official Documentation Places:
- [Public APIs GitHub](https://github.com/public-apis/public-apis)
- [RapidAPI Hub](https://rapidapi.com/)
- [API List](https://apilist.club/)
- [AnyAPI](https://any-api.com/)

### Learning Resources:
- [MDN Web Docs - Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)
- [CORS Explained](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS)
- [REST API Tutorial](https://www.restapitutorial.com/)

---

## 📝 Changelog

| Version | Changes |
|---------|---------|
| 1.0.0 | Initial release with 55 APIs |
| 1.1.0 | Added 150+ APIs |
| 1.2.0 | Added 400+ APIs |
| 1.3.0 | CORS Proxy Toggle System added |
| 1.4.0 | Browser-safe flag system |
| 1.5.0 | Details guide + API addition guide |

---

## 🤝 Contributing

Agar aap chahte hain ki main kuch naye features add karoon ya bugs fix karoon, toh batayein!

**Possible improvements:**
- More APIs (325+ ready to add)
- Export favorites to CSV/JSON
- API health monitoring
- Rate limit calculator
- Custom proxy configuration

---

## 📄 License

This project is for educational purposes. APIs and their data belong to their respective owners/providers.

---

## 🙏 Credits

- All API providers for making free tiers available
- Community for maintaining public APIs
- You for using this app!

---

**Made with ❤️ for developers worldwide**

🌐 **Happy API Exploring!** 🚀
