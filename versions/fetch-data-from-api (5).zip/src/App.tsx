import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  API_DATA,
  CATEGORIES,
  formatAuth,
  formatFreeTier,
  getCategoryEmoji,
  type ApiCategory,
  type ApiEntry,
  type AuthType,
} from "./apiData";

type SortBy = "id" | "name" | "category";
type AuthFilter = "all" | AuthType;
type CategoryFilter = "all" | ApiCategory;

function classNames(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

async function copyToClipboard(text: string) {
  try {
    if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // fallback below
  }

  try {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "true");
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    textarea.style.pointerEvents = "none";
    document.body.appendChild(textarea);
    textarea.select();
    textarea.setSelectionRange(0, text.length);
    const copied = document.execCommand("copy");
    document.body.removeChild(textarea);
    return copied;
  } catch {
    return false;
  }
}

function joinUrl(baseUrl?: string, endpoint?: string) {
  if (!baseUrl) return "";
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl.slice(0, -1) : baseUrl;
  if (endpoint === undefined || endpoint === null || endpoint === "") return normalizedBase;
  return `${normalizedBase}${endpoint.startsWith("/") ? endpoint : `/${endpoint}`}`;
}

function loadFavorites() {
  if (typeof window === "undefined") return [] as number[];
  try {
    const raw = window.localStorage.getItem("api-favorites");
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((value): value is number => typeof value === "number") : [];
  } catch {
    return [];
  }
}

function BrowserDemoStatus({ api }: { api: ApiEntry }) {
  const canRun = canRunBrowserDemo(api);

  return (
    <div
      className={classNames(
        "rounded-2xl p-4 text-sm ring-1 ring-inset",
        canRun
          ? "bg-emerald-50 text-emerald-900 ring-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-100 dark:ring-emerald-900/50"
          : "bg-amber-50 text-amber-900 ring-amber-200 dark:bg-amber-950/30 dark:text-amber-100 dark:ring-amber-900/50"
      )}
    >
      <div className="font-medium">{canRun ? "Browser live demo available" : "Browser live demo limited"}</div>
      <p className="mt-1 leading-relaxed opacity-90">{getDemoUnavailableReason(api)}</p>
    </div>
  );
}

function canRunBrowserDemo(api: ApiEntry) {
  const method = api.demoMethod ?? "GET";
  return Boolean(api.baseUrl) && api.demoEndpoint !== undefined && method === "GET" && api.auth === "NONE" && api.cors !== "No";
}

function getDemoUnavailableReason(api: ApiEntry) {
  if (!api.baseUrl || api.demoEndpoint === undefined) {
    return "This entry documents the API, but a safe browser demo endpoint has not been configured yet.";
  }

  if (canRunBrowserDemo(api)) {
    return "This endpoint can usually be fetched directly from the browser in real time.";
  }

  if (api.auth !== "NONE") {
    return "This API usually needs a key, OAuth token, or login. For security, use the cURL example or a backend/serverless function instead of direct browser fetch.";
  }

  if ((api.demoMethod ?? "GET") !== "GET") {
    return "This demo requires a POST request or custom request body, so browser live preview is intentionally disabled to avoid broken requests.";
  }

  if (api.cors === "No") {
    return "This provider blocks browser cross-origin requests (CORS). The endpoint still works from your backend, terminal, Postman, or serverless function.";
  }

  return "This API may work outside the browser, but direct client-side preview is restricted or unreliable.";
}

function CopyButton({ text, label = "Copy" }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const [failed, setFailed] = useState(false);

  return (
    <button
      onClick={async () => {
        const ok = await copyToClipboard(text);
        setFailed(!ok);
        setCopied(ok);
        window.setTimeout(() => {
          setCopied(false);
          setFailed(false);
        }, 1600);
      }}
      className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-slate-800 active:scale-95 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
      type="button"
    >
      {copied ? (
        <>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 6 9 17l-5-5" />
          </svg>
          Copied
        </>
      ) : failed ? (
        <>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 8v4" />
            <path d="M12 16h.01" />
          </svg>
          Failed
        </>
      ) : (
        <>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
          </svg>
          {label}
        </>
      )}
    </button>
  );
}

function Badge({ children, color = "slate" }: { children: ReactNode; color?: string }) {
  const colors: Record<string, string> = {
    emerald:
      "bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-950/50 dark:text-emerald-300 dark:ring-emerald-400/30",
    amber:
      "bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-950/50 dark:text-amber-300 dark:ring-amber-400/30",
    blue: "bg-blue-50 text-blue-700 ring-blue-600/20 dark:bg-blue-950/50 dark:text-blue-300 dark:ring-blue-400/30",
    violet:
      "bg-violet-50 text-violet-700 ring-violet-600/20 dark:bg-violet-950/50 dark:text-violet-300 dark:ring-violet-400/30",
    slate: "bg-slate-50 text-slate-700 ring-slate-600/10 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700",
    rose: "bg-rose-50 text-rose-700 ring-rose-600/20 dark:bg-rose-950/50 dark:text-rose-300 dark:ring-rose-400/30",
  };

  return (
    <span className={classNames("inline-flex items-center rounded-md px-2 py-1 text-xs font-medium ring-1 ring-inset", colors[color] || colors.slate)}>
      {children}
    </span>
  );
}

function Modal({ api, onClose }: { api: ApiEntry | null; onClose: () => void }) {
  const [demoData, setDemoData] = useState<unknown>(null);
  const [demoLoading, setDemoLoading] = useState(false);
  const [demoError, setDemoError] = useState<string | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!api) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    setDemoData(null);
    setDemoError(null);

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };

    window.addEventListener("keydown", onKeyDown);
    window.setTimeout(() => closeButtonRef.current?.focus(), 0);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [api, onClose]);

  if (!api) return null;

  const auth = formatAuth(api.auth);
  const tier = formatFreeTier(api.freeTier);
  const demoUrl = api.baseUrl ? `${joinUrl(api.baseUrl, api.demoEndpoint)}${api.demoParams ? `?${new URLSearchParams(api.demoParams).toString()}` : ""}` : "";
  const browserDemoEnabled = canRunBrowserDemo(api);

  const runLiveDemo = async () => {
    if (!browserDemoEnabled || !api.baseUrl || api.demoEndpoint === undefined) {
      setDemoData(null);
      setDemoError(getDemoUnavailableReason(api));
      return;
    }

    setDemoLoading(true);
    setDemoError(null);
    setDemoData(null);

    try {
      const url = new URL(joinUrl(api.baseUrl, api.demoEndpoint));
      if (api.demoParams) {
        Object.entries(api.demoParams).forEach(([key, value]) => {
          url.searchParams.set(key, value);
        });
      }

      const controller = new AbortController();
      const timeout = window.setTimeout(() => controller.abort(), 10000);

      const response = await fetch(url.toString(), {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        signal: controller.signal,
      });

      window.clearTimeout(timeout);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get("content-type") || "";
      if (contentType.includes("application/json")) {
        setDemoData(await response.json());
      } else {
        const text = await response.text();
        setDemoData({ text: text.slice(0, 3000) });
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to fetch";
      setDemoError(message === "The operation was aborted." ? "Request timed out after 10 seconds." : message);
    } finally {
      setDemoLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-950/70 p-4 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      role="presentation"
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="api-modal-title"
        className="my-8 w-full max-w-4xl rounded-3xl bg-white shadow-2xl ring-1 ring-slate-900/5 dark:bg-slate-900 dark:ring-white/10"
      >
        <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-slate-200 bg-white/85 p-6 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-900/85 sm:p-8">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1.5">
                <span className="text-lg">{getCategoryEmoji(api.category)}</span>
                {api.category}
              </span>
              <span>•</span>
              <span>{api.provider}</span>
            </div>
            <h2 id="api-modal-title" className="mt-2 text-2xl font-semibold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
              {api.name}
            </h2>
            <p className="mt-2 max-w-3xl text-slate-600 dark:text-slate-300">{api.description}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Badge color={auth.color}>
                <span className="mr-1">{auth.icon}</span>
                {auth.label}
              </Badge>
              <Badge color={tier.color}>{tier.label}</Badge>
              <Badge color={api.cors === "Yes" ? "emerald" : api.cors === "Partial" ? "amber" : "rose"}>CORS: {api.cors}</Badge>
              <Badge color="slate">{api.limits}</Badge>
              <Badge color="slate">#{api.id}</Badge>
            </div>
          </div>

          <button
            ref={closeButtonRef}
            onClick={onClose}
            type="button"
            aria-label="Close details dialog"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-500 transition hover:bg-slate-200 hover:text-slate-700 focus:outline-none focus:ring-4 focus:ring-violet-500/20 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700 dark:hover:text-slate-200"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="grid gap-8 p-6 sm:grid-cols-2 sm:p-8">
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Auth, Limits & Access</h3>
              <div className="mt-3 space-y-4 rounded-2xl bg-slate-50 p-4 dark:bg-slate-800/50">
                <div>
                  <div className="text-sm font-medium text-slate-900 dark:text-slate-100">Authentication</div>
                  <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
                    {api.auth === "NONE"
                      ? "No auth is listed for this entry. Great for testing or fast prototyping if the provider allows browser access."
                      : api.auth === "Key"
                        ? "API key required. Keep keys on the server or inside serverless functions — never hard-code them in public client builds."
                        : api.auth === "OAuth"
                          ? "OAuth flow required. This is common for user-account APIs like Google, Spotify, or Discord."
                          : "Account login or platform authentication is required before using this API."}
                  </p>
                </div>

                <div className="h-px bg-slate-200 dark:bg-slate-700" />

                <div>
                  <div className="text-sm font-medium text-slate-900 dark:text-slate-100">Rate limits</div>
                  <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{api.limits}</p>
                  <p className="mt-2 text-xs leading-relaxed text-slate-500 dark:text-slate-400">{api.rateLimitDetails}</p>
                </div>

                <div className="h-px bg-slate-200 dark:bg-slate-700" />

                <div>
                  <div className="text-sm font-medium text-slate-900 dark:text-slate-100">Provider & links</div>
                  <div className="mt-2 flex flex-wrap gap-3">
                    <a
                      href={api.website}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800 active:scale-95 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
                    >
                      Visit Website
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M7 17 17 7" />
                        <path d="M7 7h10v10" />
                      </svg>
                    </a>
                    <a
                      href={api.docs}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-medium text-slate-700 ring-1 ring-inset ring-slate-300 transition hover:bg-slate-50 active:scale-95 dark:bg-slate-800 dark:text-slate-200 dark:ring-slate-700 dark:hover:bg-slate-700"
                    >
                      Read Docs
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
                        <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
                      </svg>
                    </a>
                  </div>
                  {api.baseUrl && (
                    <div className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                      Base URL:
                      <div className="mt-1 overflow-x-auto rounded-xl bg-slate-950 px-3 py-2 font-mono text-slate-100 dark:bg-black">{api.baseUrl}</div>
                    </div>
                  )}
                </div>

                {api.requiresSignup && (
                  <div className="rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-800 ring-1 ring-inset ring-amber-200 dark:bg-amber-950/30 dark:text-amber-200 dark:ring-amber-900/50">
                    ⚠️ This API usually needs a free account, developer app, or provider signup before real usage.
                  </div>
                )}
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Use Cases</h3>
              <div className="mt-3 flex flex-wrap gap-2">
                {api.useCases.map((useCase) => (
                  <span
                    key={useCase}
                    className="rounded-full bg-violet-50 px-3 py-1 text-sm text-violet-700 ring-1 ring-inset ring-violet-200 dark:bg-violet-950/50 dark:text-violet-300 dark:ring-violet-800"
                  >
                    {useCase}
                  </span>
                ))}
              </div>
            </div>

            {api.whyUse && (
              <div>
                <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Why use this API?</h3>
                <p className="mt-3 rounded-2xl bg-emerald-50 p-4 text-sm leading-relaxed text-emerald-900 ring-1 ring-inset ring-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-100 dark:ring-emerald-900/50">
                  {api.whyUse}
                </p>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Example Request</h3>
                {api.exampleRequest && <CopyButton text={api.exampleRequest} label="Copy cURL" />}
              </div>
              <pre className="mt-3 overflow-x-auto rounded-2xl bg-slate-950 p-4 text-xs leading-relaxed text-slate-100 dark:bg-black">
                <code>{api.exampleRequest || "No example request configured for this entry yet."}</code>
              </pre>
            </div>

            {api.tips && api.tips.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">How to use it well</h3>
                <ul className="mt-3 space-y-2">
                  {api.tips.map((tip, index) => (
                    <li key={`${api.id}-${index}`} className="flex gap-2 text-sm text-slate-600 dark:text-slate-300">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-violet-500" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="rounded-2xl bg-slate-50 p-5 dark:bg-slate-800/50">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Implementation checklist</h3>
              <div className="mt-3 space-y-3 text-sm text-slate-600 dark:text-slate-300">
                <p>1. Read the official docs and confirm auth flow, quotas, and request format.</p>
                <p>2. Put secrets behind backend routes, serverless functions, or env vars.</p>
                <p>3. Add caching, retries, and timeout handling to respect provider limits.</p>
                <p>4. Show graceful fallback UI if the provider is down or CORS blocks browser access.</p>
              </div>
            </div>

            <BrowserDemoStatus api={api} />
          </div>
        </div>

        {api.baseUrl && api.demoEndpoint !== undefined && (
          <div className="border-t border-slate-200 bg-slate-50/50 p-6 dark:border-slate-800 dark:bg-slate-900/50 sm:p-8">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">Live Demo</h3>
                <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Real browser fetch preview for safe, public endpoints only.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={runLiveDemo}
                  disabled={!browserDemoEnabled || demoLoading}
                  type="button"
                  className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-violet-500 disabled:cursor-not-allowed disabled:opacity-50 active:scale-95"
                >
                  {demoLoading ? (
                    <>
                      <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                      </svg>
                      Fetching...
                    </>
                  ) : (
                    <>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                      </svg>
                      Try live
                    </>
                  )}
                </button>
                {demoData !== null && <CopyButton text={JSON.stringify(demoData, null, 2)} label="Copy JSON" />}
              </div>
            </div>

            {demoUrl && (
              <p className="mt-4 text-xs text-slate-500 dark:text-slate-400">
                URL:{" "}
                <code className="rounded bg-slate-200 px-1.5 py-0.5 font-mono text-[11px] dark:bg-slate-800 dark:text-slate-300">{demoUrl}</code>
              </p>
            )}

            <div className="mt-4 rounded-2xl bg-slate-950 p-4 dark:bg-black">
              {demoLoading && (
                <div className="flex items-center justify-center py-12 text-slate-400">
                  <svg className="mr-3 animate-spin" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                  </svg>
                  Fetching real data from the provider...
                </div>
              )}

              {demoError && !demoLoading && (
                <div className="rounded-xl bg-rose-950/50 p-4 text-sm text-rose-200 ring-1 ring-rose-900">
                  ❌ {demoError}
                </div>
              )}

              {demoData !== null && !demoLoading && (
                <div className="relative">
                  <pre className="max-h-[420px] overflow-auto text-xs leading-relaxed text-slate-100">
                    <code>{JSON.stringify(demoData, null, 2)}</code>
                  </pre>
                  <div className="absolute right-3 top-3 hidden sm:block">
                    <CopyButton text={JSON.stringify(demoData, null, 2)} label="Copy response" />
                  </div>
                </div>
              )}

              {!demoLoading && !demoError && !demoData && (
                <div className="py-12 text-center text-sm text-slate-400">{getDemoUnavailableReason(api)}</div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("all");
  const [authFilter, setAuthFilter] = useState<AuthFilter>("all");
  const [sortBy, setSortBy] = useState<SortBy>("id");
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [selected, setSelected] = useState<ApiEntry | null>(null);
  const [favorites, setFavorites] = useState<number[]>(loadFavorites);

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem("api-favorites", JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (id: number) => {
    setFavorites((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  };

  const filtered = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    let list = [...API_DATA];

    if (normalizedQuery) {
      list = list.filter((api) => {
        const searchable = [
          api.name,
          api.provider,
          api.category,
          api.description,
          api.limits,
          api.rateLimitDetails,
          api.whyUse ?? "",
          ...api.useCases,
          ...(api.tips ?? []),
        ]
          .join(" ")
          .toLowerCase();

        return searchable.includes(normalizedQuery);
      });
    }

    if (categoryFilter !== "all") {
      list = list.filter((api) => api.category === categoryFilter);
    }

    if (authFilter !== "all") {
      list = list.filter((api) => api.auth === authFilter);
    }

    if (showFavoritesOnly) {
      list = list.filter((api) => favorites.includes(api.id));
    }

    list.sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name);
      if (sortBy === "category") return a.category.localeCompare(b.category) || a.name.localeCompare(b.name);
      return a.id - b.id;
    });

    return list;
  }, [authFilter, categoryFilter, favorites, query, showFavoritesOnly, sortBy]);

  const stats = useMemo(() => {
    const noAuth = API_DATA.filter((api) => api.auth === "NONE").length;
    const free = API_DATA.filter((api) => api.freeTier === "Free").length;
    const browserReady = API_DATA.filter((api) => canRunBrowserDemo(api)).length;
    return {
      total: API_DATA.length,
      noAuth,
      free,
      browserReady,
      favorites: favorites.length,
    };
  }, [favorites.length]);

  const hasActiveFilters = Boolean(query) || categoryFilter !== "all" || authFilter !== "all" || showFavoritesOnly || sortBy !== "id";

  const resetFilters = () => {
    setQuery("");
    setCategoryFilter("all");
    setAuthFilter("all");
    setSortBy("id");
    setShowFavoritesOnly(false);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 antialiased dark:bg-slate-950 dark:text-slate-100">
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808010_1px,transparent_1px),linear-gradient(to_bottom,#80808010_1px,transparent_1px)] bg-[size:24px_24px]" />
        <div className="absolute left-1/2 top-0 h-[600px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-300/20 blur-[120px] dark:bg-violet-900/20" />
      </div>

      <header className="sticky top-0 z-30 border-b border-slate-200/60 bg-white/70 backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-950/70">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-600/20">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 18 22 12 16 6" />
                <path d="M8 6 2 12 8 18" />
              </svg>
            </div>
            <div className="min-w-0">
              <div className="truncate text-lg font-semibold tracking-tight sm:text-xl">Free API Encyclopedia</div>
              <div className="hidden text-xs text-slate-500 dark:text-slate-400 sm:block">
                {stats.total} documented APIs • real limits • browser-safe live demos
              </div>
            </div>
          </div>

          <div className="hidden items-center gap-3 sm:flex">
            <Badge color="emerald">{stats.noAuth} No Auth</Badge>
            <Badge color="blue">{stats.browserReady} Browser Demo</Badge>
            <Badge color="violet">{stats.free} Free Tier</Badge>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-[2rem] border border-slate-200 bg-gradient-to-br from-violet-50 via-white to-indigo-50 p-8 shadow-sm dark:border-slate-800 dark:from-violet-950/20 dark:via-slate-900 dark:to-indigo-950/20 sm:p-12">
          <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-violet-400/20 blur-[100px]" />
          <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-indigo-400/20 blur-[100px]" />
          <div className="relative">
            <div className="inline-flex items-center gap-2 rounded-full bg-white/60 px-3 py-1 text-xs font-medium text-slate-600 ring-1 ring-inset ring-slate-200 backdrop-blur dark:bg-slate-900/60 dark:text-slate-300 dark:ring-slate-800">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              Verified directory • 2026-ready API discovery
            </div>
            <h1 className="mt-6 max-w-4xl text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl lg:text-5xl">
              Browse <span className="bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">{stats.total} documented free APIs</span> with cleaner details, real limits, and safer live previews.
            </h1>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-slate-600 dark:text-slate-300 sm:text-lg">
              Search by provider, category, or use case. Open any entry to inspect auth, limits, cURL examples, implementation tips, and browser demo availability.
            </p>

            <div className="mt-8 grid gap-4 sm:grid-cols-4">
              <div className="rounded-2xl bg-white/70 p-4 ring-1 ring-slate-200 backdrop-blur dark:bg-slate-900/70 dark:ring-slate-800">
                <div className="text-2xl font-semibold text-slate-900 dark:text-white">{stats.total}</div>
                <div className="text-sm text-slate-600 dark:text-slate-400">APIs in catalog</div>
              </div>
              <div className="rounded-2xl bg-white/70 p-4 ring-1 ring-slate-200 backdrop-blur dark:bg-slate-900/70 dark:ring-slate-800">
                <div className="text-2xl font-semibold text-emerald-600 dark:text-emerald-400">{stats.noAuth}</div>
                <div className="text-sm text-slate-600 dark:text-slate-400">No-auth entries</div>
              </div>
              <div className="rounded-2xl bg-white/70 p-4 ring-1 ring-slate-200 backdrop-blur dark:bg-slate-900/70 dark:ring-slate-800">
                <div className="text-2xl font-semibold text-blue-600 dark:text-blue-400">{stats.browserReady}</div>
                <div className="text-sm text-slate-600 dark:text-slate-400">Browser-safe demos</div>
              </div>
              <div className="rounded-2xl bg-white/70 p-4 ring-1 ring-slate-200 backdrop-blur dark:bg-slate-900/70 dark:ring-slate-800">
                <div className="text-2xl font-semibold text-violet-600 dark:text-violet-400">{stats.favorites}</div>
                <div className="text-sm text-slate-600 dark:text-slate-400">Saved favorites</div>
              </div>
            </div>
          </div>
        </div>

        <div className="sticky top-[73px] z-20 -mx-4 mt-8 border-y border-slate-200 bg-white/80 px-4 py-4 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/80 sm:mx-0 sm:rounded-2xl sm:border sm:px-5">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <svg className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.35-4.35" />
              </svg>
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search APIs, limits, providers, auth types, or use cases..."
                className="h-11 w-full rounded-xl border border-slate-300 bg-white pl-11 pr-11 text-sm text-slate-900 placeholder-slate-500 outline-none ring-violet-500/20 transition focus:border-violet-500 focus:ring-4 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:placeholder-slate-400"
              />
              {query && (
                <button
                  onClick={() => setQuery("")}
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-300"
                  aria-label="Clear search"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 6 6 18M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={categoryFilter}
                onChange={(event) => setCategoryFilter(event.target.value as CategoryFilter)}
                className="h-11 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              >
                <option value="all">All categories</option>
                {CATEGORIES.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.emoji} {category.id}
                  </option>
                ))}
              </select>

              <select
                value={authFilter}
                onChange={(event) => setAuthFilter(event.target.value as AuthFilter)}
                className="h-11 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              >
                <option value="all">All auth types</option>
                <option value="NONE">✓ No Auth</option>
                <option value="Key">🔑 API Key</option>
                <option value="OAuth">🔐 OAuth</option>
                <option value="LOGIN_REQUIRED">👤 Login</option>
              </select>

              <select
                value={sortBy}
                onChange={(event) => setSortBy(event.target.value as SortBy)}
                className="h-11 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              >
                <option value="id">Sort by ID</option>
                <option value="name">Sort by name</option>
                <option value="category">Sort by category</option>
              </select>

              <button
                type="button"
                onClick={() => setShowFavoritesOnly((current) => !current)}
                disabled={favorites.length === 0}
                className={classNames(
                  "inline-flex h-11 items-center gap-2 rounded-xl px-3 text-sm font-medium ring-1 ring-inset transition",
                  showFavoritesOnly
                    ? "bg-rose-50 text-rose-700 ring-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:ring-rose-900/60"
                    : "bg-white text-slate-700 ring-slate-300 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-200 dark:ring-slate-700 dark:hover:bg-slate-800",
                  favorites.length === 0 && "cursor-not-allowed opacity-50"
                )}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill={showFavoritesOnly ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                </svg>
                Favorites {favorites.length > 0 ? `(${favorites.length})` : ""}
              </button>

              {hasActiveFilters && (
                <button
                  type="button"
                  onClick={resetFilters}
                  className="inline-flex h-11 items-center rounded-xl bg-slate-900 px-3 text-sm font-medium text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
                >
                  Reset
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Showing <span className="font-medium text-slate-900 dark:text-slate-100">{filtered.length}</span> of {stats.total} APIs
            {query && (
              <>
                {" "}for <span className="font-medium text-slate-900 dark:text-slate-100">“{query}”</span>
              </>
            )}
            {showFavoritesOnly && <> • favorites only</>}
          </p>

          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((category) => {
              const active = categoryFilter === category.id;
              return (
                <button
                  key={category.id}
                  type="button"
                  onClick={() => setCategoryFilter(active ? "all" : category.id)}
                  className={classNames(
                    "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium ring-1 ring-inset transition",
                    active
                      ? "bg-violet-50 text-violet-700 ring-violet-200 dark:bg-violet-950/40 dark:text-violet-300 dark:ring-violet-900/50"
                      : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-300 dark:ring-slate-800 dark:hover:bg-slate-800"
                  )}
                >
                  <span>{category.emoji}</span>
                  <span>{category.id}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((api) => {
            const auth = formatAuth(api.auth);
            const tier = formatFreeTier(api.freeTier);
            const isFavorite = favorites.includes(api.id);
            const browserDemo = canRunBrowserDemo(api);

            return (
              <article
                key={api.id}
                className="group relative flex h-full flex-col rounded-[1.5rem] border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg hover:shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:hover:shadow-black/20"
              >
                <button
                  onClick={() => toggleFavorite(api.id)}
                  type="button"
                  className={classNames(
                    "absolute right-4 top-4 z-10 flex h-8 w-8 items-center justify-center rounded-full transition",
                    isFavorite
                      ? "bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400"
                      : "bg-slate-100 text-slate-400 hover:bg-slate-200 hover:text-slate-600 dark:bg-slate-800 dark:text-slate-500 dark:hover:bg-slate-700 dark:hover:text-slate-300"
                  )}
                  aria-label={isFavorite ? "Remove favorite" : "Add favorite"}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill={isFavorite ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                  </svg>
                </button>

                <div className="flex items-start gap-3">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-slate-100 text-2xl dark:bg-slate-800">
                    {getCategoryEmoji(api.category)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="pr-8 text-base font-semibold leading-tight text-slate-900 dark:text-white">{api.name}</h3>
                      <div className="shrink-0 text-xs font-medium text-slate-400">#{api.id}</div>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                      <span className="truncate">{api.provider}</span>
                      <span>•</span>
                      <span className="truncate">{api.category}</span>
                    </div>
                  </div>
                </div>

                <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">{api.description}</p>

                <div className="mt-4 flex flex-wrap gap-1.5">
                  <Badge color={auth.color}>
                    <span className="mr-1">{auth.icon}</span>
                    {auth.label}
                  </Badge>
                  <Badge color={tier.color}>{tier.label}</Badge>
                  <Badge color="slate">{api.limits}</Badge>
                </div>

                <div className="mt-4 flex flex-wrap gap-1.5">
                  <Badge color={browserDemo ? "blue" : api.cors === "No" ? "rose" : "amber"}>
                    {browserDemo ? "Live demo ready" : api.cors === "No" ? "Backend only" : "Docs / cURL"}
                  </Badge>
                  <Badge color={api.cors === "Yes" ? "emerald" : api.cors === "Partial" ? "amber" : "rose"}>CORS {api.cors}</Badge>
                </div>

                <div className="mt-4 flex flex-wrap gap-1">
                  {api.useCases.slice(0, 3).map((useCase) => (
                    <span key={useCase} className="rounded-md bg-slate-100 px-2 py-1 text-[11px] text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                      {useCase}
                    </span>
                  ))}
                  {api.useCases.length > 3 && (
                    <span className="rounded-md bg-slate-100 px-2 py-1 text-[11px] text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                      +{api.useCases.length - 3}
                    </span>
                  )}
                </div>

                <div className="mt-auto pt-5">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelected(api)}
                      type="button"
                      className="flex-1 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800 active:scale-[0.98] dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
                    >
                      View details
                    </button>
                    <a
                      href={api.website}
                      target="_blank"
                      rel="noreferrer"
                      className="flex h-[42px] w-[42px] items-center justify-center rounded-xl border border-slate-300 text-slate-600 transition hover:bg-slate-50 active:scale-95 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
                      aria-label={`Visit ${api.name} website`}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                        <polyline points="15 3 21 3 21 9" />
                        <line x1="10" y1="14" x2="21" y2="3" />
                      </svg>
                    </a>
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="mt-16 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400">
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.35-4.35" />
              </svg>
            </div>
            <h3 className="mt-4 text-lg font-medium text-slate-900 dark:text-white">No APIs found</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Try changing the search, auth filter, category, or favorites toggle.</p>
            <button onClick={resetFilters} type="button" className="mt-4 text-sm font-medium text-violet-600 hover:text-violet-500 dark:text-violet-400">
              Clear all filters
            </button>
          </div>
        )}

        <div className="mt-20 grid gap-6 rounded-[2rem] border border-slate-200 bg-slate-50 p-8 dark:border-slate-800 dark:bg-slate-900/50 sm:grid-cols-3">
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">What is verified here</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li>• Auth type and access requirements</li>
              <li>• Free tier and visible rate-limit notes</li>
              <li>• Official website and docs links</li>
              <li>• Safer browser live demo handling</li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Best practices</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li>• Cache responses for 30 min when possible</li>
              <li>• Never expose private API keys in client builds</li>
              <li>• Use backend or serverless wrappers for protected APIs</li>
              <li>• Design fallback UI for outages and CORS failures</li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Deployment notes</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li>• Favicon assets are now included for Vercel/static hosting</li>
              <li>• Title and meta tags are optimized for rendering</li>
              <li>• Browser demos only run for safe public GET endpoints</li>
              <li>• Source data stays easy to extend in <code className="font-mono">src/apiData.ts</code></li>
            </ul>
          </div>
        </div>
      </main>

      <Modal api={selected} onClose={() => setSelected(null)} />
    </div>
  );
}
